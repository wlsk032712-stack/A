# 플레이스픽(PlacePick) 회원가입 플로우

피그마 와이어프레임을 그대로 구현한 실행 가능한 React 프로젝트입니다.

## 화면 구성
splash → login → signupTerms(약관동의) → signupId(아이디) → signupPassword(비밀번호)
→ signupPhone(휴대폰 본인인증) → signupDone(가입완료)

## 별도 기능: 지도에서 맛집 검색/추가 (`src/MapPlaceSearchFlow.jsx`)
회원가입과 무관한 독립 기능입니다. intro → collect(안내+검색창) → search(검색 결과 목록)
→ confirm(지도 플레이스홀더 + 하단 시트로 상세 확인 및 저장하기)
실제 지도 SDK(카카오맵/네이버맵/구글맵 등)는 아직 연결되어 있지 않아서
`MapPlaceholder` 컴포넌트를 실제 지도 SDK로 교체하면 됩니다.

이 화면을 확인하려면 `src/main.jsx`에서 `import App from "./App.jsx"` 대신
`import App from "./MapPlaceSearchFlow.jsx"`로 바꿔서 실행하면 됩니다.


## 실행 방법
```bash
npm install
npm run dev
```
터미널에 뜨는 주소(예: http://localhost:5173)를 브라우저로 열면 됩니다.

## 서버 연동
`src/App.jsx` 상단에 있는 아래 mock 함수들만 실제 API 호출로 바꾸면 됩니다.
- loginUser(id, password)
- checkIdDuplicate(id)
- requestPhoneVerification(payload)
- confirmVerificationCode(code)
- completeSignUp(payload)

검색/장소 저장 관련 mock 데이터(MOCK_PLACES, MOCK_DETAIL)와 저장 API 호출부는
`OnboardingSearchScreen`, `OnboardingSearchWithSheet` 안에 있습니다.
