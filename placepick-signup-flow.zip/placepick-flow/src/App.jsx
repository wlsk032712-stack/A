import React, { useState, useCallback, useEffect, useRef } from "react";

/**
 * 플레이스픽 (PlacePick) — 전체 회원가입 플로우
 * ------------------------------------------------------------
 * splash → login → signupTerms → signupId → signupPassword
 *   → signupPhone(본인인증 입력 + 인증번호 입력) → signupDone
 *
 * 서버 연동 지점 (지금은 mock, 실제 API로 교체):
 *   - loginUser(id, password)
 *   - checkIdDuplicate(id)
 *   - completeSignUp(payload)
 *   - requestPhoneVerification(payload)
 *   - confirmVerificationCode(code)
 */

// ----------------------------------------------------
// 서버 연동 지점 (mock)
// ----------------------------------------------------
async function loginUser(userId, password) {
  await new Promise((r) => setTimeout(r, 500));
  if (!userId || !password) throw new Error("아이디와 비밀번호를 입력해주세요.");
  return { id: userId };
}

async function checkIdDuplicate(id) {
  // TODO: 실제 아이디 중복확인 API로 교체
  await new Promise((r) => setTimeout(r, 400));
  return id.toLowerCase() === "test";
}

async function requestPhoneVerification({ name, residentFront, carrier, phone }) {
  // TODO: 실제 본인인증(문자 인증번호 발송) API로 교체
  await new Promise((r) => setTimeout(r, 500));
  return { success: true };
}

async function confirmVerificationCode(code) {
  // TODO: 실제 인증번호 확인 API로 교체
  await new Promise((r) => setTimeout(r, 400));
  return code.length === 6;
}

async function completeSignUp(payload) {
  // TODO: 실제 회원가입 확정 API로 교체
  await new Promise((r) => setTimeout(r, 500));
  return { success: true, ...payload };
}

// ----------------------------------------------------
// 공통 UI 조각
// ----------------------------------------------------
function StatusBar() {
  return (
    <div style={s.statusBar}>
      <span>9:41</span>
      <span style={s.statusIcons}>
        <i className="ti ti-antenna-bars-5" style={{ fontSize: 14 }} />
        <i className="ti ti-wifi" style={{ fontSize: 14 }} />
        <i className="ti ti-battery-4" style={{ fontSize: 14 }} />
      </span>
    </div>
  );
}

function HomeIndicator() {
  return (
    <div style={s.homeIndicatorWrap}>
      <div style={s.homeIndicator} />
    </div>
  );
}

function PhoneFrame({ children }) {
  return <div style={s.phone}>{children}</div>;
}

// 회원가입 하위 단계 공통 헤더: 뒤로가기 + 진행바
function StepHeader({ onBack, step, totalSteps }) {
  const pct = Math.round((step / totalSteps) * 100);
  return (
    <>
      <div style={s.signupHeaderRow}>
        <button type="button" onClick={onBack} style={s.backButton} aria-label="뒤로가기">
          <i className="ti ti-arrow-left" style={{ fontSize: 20 }} />
        </button>
      </div>
      <div style={s.progressWrap}>
        <div style={s.progressBarBg}>
          <div style={{ ...s.progressBarFill, width: `${pct}%` }} />
        </div>
      </div>
    </>
  );
}

// ----------------------------------------------------
// 화면 1: 스플래시
// ----------------------------------------------------
function SplashScreen({ onFinish }) {
  useEffect(() => {
    const t = setTimeout(onFinish, 1200);
    return () => clearTimeout(t);
  }, [onFinish]);

  return (
    <PhoneFrame>
      <StatusBar />
      <div style={s.splashBody} onClick={onFinish}>
        <div style={s.logoPlaceholder}>
          <i className="ti ti-photo-x" style={{ fontSize: 28, color: "#B4B2A9" }} />
        </div>
        <p style={s.splashTitle}>PlacePick</p>
      </div>
      <div style={s.bottomTextWrap}>
        <p style={s.bottomText}>당신을 위한 최적의 공간 선택</p>
        <div style={s.dots}>
          <span style={s.dot} />
          <span style={s.dot} />
          <span style={s.dot} />
        </div>
      </div>
      <HomeIndicator />
    </PhoneFrame>
  );
}

// ----------------------------------------------------
// 화면 2: 로그인
// ----------------------------------------------------
function LoginScreen({ onGoSignUp, onLoginSuccess }) {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleLogin = useCallback(
    async (e) => {
      e.preventDefault();
      setError("");
      setSubmitting(true);
      try {
        const user = await loginUser(userId, password);
        onLoginSuccess?.(user);
      } catch (err) {
        setError(err.message);
      } finally {
        setSubmitting(false);
      }
    },
    [userId, password, onLoginSuccess]
  );

  return (
    <PhoneFrame>
      <StatusBar />
      <form onSubmit={handleLogin} style={s.loginBody}>
        <p style={s.loginTitle}>PlacePick</p>
        <p style={s.loginSubtitle}>당신만의 인생 맛집을 찾아보세요</p>

        <input
          type="text"
          placeholder="아이디를 입력하세요."
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          style={s.input}
        />
        <input
          type="password"
          placeholder="비밀번호를 입력하세요."
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ ...s.input, marginTop: 10 }}
        />

        <button
          type="button"
          style={s.guestLinkCentered}
          onClick={() => window.alert("비회원으로 시작합니다.")}
        >
          비회원으로 시작하기
        </button>

        {error && <p style={s.loginError}>{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          style={{ ...s.loginButton, opacity: submitting ? 0.6 : 1 }}
        >
          {submitting ? "로그인 중..." : "로그인"}
        </button>

        <div style={s.linkRow}>
          <button type="button" style={s.linkText} onClick={() => window.alert("아이디 찾기")}>
            아이디 찾기
          </button>
          <span style={s.linkDivider}>|</span>
          <button type="button" style={s.linkText} onClick={() => window.alert("비밀번호 찾기")}>
            비밀번호 찾기
          </button>
          <span style={s.linkDivider}>|</span>
          <button type="button" style={s.linkText} onClick={onGoSignUp}>
            회원가입
          </button>
        </div>
      </form>

      <HomeIndicator />
    </PhoneFrame>
  );
}

// ----------------------------------------------------
// 화면 3: 회원가입 - 약관동의
// ----------------------------------------------------
const TERMS_CONFIG = [
  { key: "age14", label: "만 14세 이상", required: true, viewable: false },
  { key: "service", label: "이용약관 동의", required: true, viewable: true },
  { key: "privacy", label: "개인정보 처리방침 동의", required: true, viewable: true },
  { key: "marketing", label: "광고성 정보 수신 및 마케팅 활용 동의", required: false, viewable: true },
];

function SignUpTermsScreen({ onBack, onNext }) {
  const [checked, setChecked] = useState({
    age14: false,
    service: false,
    privacy: false,
    marketing: false,
  });

  const requiredKeys = TERMS_CONFIG.filter((t) => t.required).map((t) => t.key);
  const allKeys = TERMS_CONFIG.map((t) => t.key);
  const allChecked = allKeys.every((k) => checked[k]);
  const requiredChecked = requiredKeys.every((k) => checked[k]);

  const toggleOne = (key) => setChecked((prev) => ({ ...prev, [key]: !prev[key] }));

  const toggleAll = () => {
    const next = !allChecked;
    const updated = {};
    allKeys.forEach((k) => (updated[k] = next));
    setChecked(updated);
  };

  return (
    <PhoneFrame>
      <StatusBar />
      <StepHeader onBack={onBack} step={1} totalSteps={5} />

      <div style={s.signupBody}>
        <p style={s.signupTitle}>
          <b>PlacePick</b>의 서비스 이용약관에 동의해주세요
        </p>

        <div style={s.termsList}>
          {TERMS_CONFIG.map((t) => (
            <div key={t.key} style={s.termRow}>
              <label style={s.termLabelWrap}>
                <input
                  type="checkbox"
                  checked={checked[t.key]}
                  onChange={() => toggleOne(t.key)}
                  style={s.checkbox}
                />
                <span style={s.termLabel}>
                  <span style={t.required ? s.requiredTag : s.optionalTag}>
                    [{t.required ? "필수" : "선택"}]
                  </span>{" "}
                  {t.label}
                </span>
              </label>
              {t.viewable && (
                <button
                  type="button"
                  style={s.viewLink}
                  onClick={() => window.alert(`${t.label} 상세 내용`)}
                >
                  보기
                </button>
              )}
            </div>
          ))}
        </div>

        <div style={s.termsDivider} />

        <label style={s.allAgreeRow}>
          <input type="checkbox" checked={allChecked} onChange={toggleAll} style={s.checkbox} />
          <span style={s.allAgreeLabel}>모두 동의 (선택 정보 포함)</span>
        </label>
      </div>

      <div style={s.signupFooter}>
        <button
          type="button"
          disabled={!requiredChecked}
          onClick={onNext}
          style={{
            ...s.primaryButton,
            opacity: !requiredChecked ? 0.4 : 1,
            cursor: !requiredChecked ? "not-allowed" : "pointer",
          }}
        >
          동의하고 가입하기
        </button>
      </div>
      <HomeIndicator />
    </PhoneFrame>
  );
}

// ----------------------------------------------------
// 화면 4: 회원가입 1-2 (1/5) - 아이디 입력
// ----------------------------------------------------
function SignUpIdScreen({ onBack, onNext }) {
  const [id, setId] = useState("");
  const [status, setStatus] = useState("idle"); // idle | checking | available | duplicate
  const [touched, setTouched] = useState(false);

  const handleChange = (e) => {
    setId(e.target.value);
    setStatus("idle");
  };

  const handleNext = async () => {
    setTouched(true);
    if (!id) return;
    setStatus("checking");
    const isDuplicate = await checkIdDuplicate(id);
    if (isDuplicate) {
      setStatus("duplicate");
      return;
    }
    setStatus("available");
    onNext(id);
  };

  return (
    <PhoneFrame>
      <StatusBar />
      <StepHeader onBack={onBack} step={2} totalSteps={5} />

      <div style={s.signupBody}>
        <p style={s.stepTitle}>
          사용할 아이디를
          <br />
          입력해주세요.
        </p>

        <input
          type="text"
          placeholder="아이디를 입력하세요."
          value={id}
          onChange={handleChange}
          style={s.input}
        />
        {touched && !id && <p style={s.fieldError}>아이디를 입력해주세요.</p>}
        {status === "duplicate" && (
          <p style={s.fieldError}>이미 사용 중인 아이디입니다.</p>
        )}
      </div>

      <div style={s.signupFooter}>
        <button
          type="button"
          onClick={handleNext}
          disabled={status === "checking"}
          style={s.primaryButton}
        >
          {status === "checking" ? "확인중..." : "다음"}
        </button>
      </div>
      <HomeIndicator />
    </PhoneFrame>
  );
}

// ----------------------------------------------------
// 화면 5-6: 회원가입 1-2 (2/5) - 비밀번호 입력
// ----------------------------------------------------
function SignUpPasswordScreen({ onBack, onNext }) {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const hasLetter = /[A-Za-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasLength = password.length >= 8 && password.length <= 20;
  const isMatch = confirm.length > 0 && password === confirm;
  const isValid = hasLetter && hasNumber && hasLength && isMatch;

  return (
    <PhoneFrame>
      <StatusBar />
      <StepHeader onBack={onBack} step={3} totalSteps={5} />

      <div style={s.signupBody}>
        <p style={s.stepTitle}>
          사용할 비밀번호를
          <br />
          입력해주세요.
        </p>

        <div style={s.inputWithIcon}>
          <input
            type={showPw ? "text" : "password"}
            placeholder="비밀번호를 입력하세요."
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={s.input}
          />
          <button
            type="button"
            style={s.eyeButton}
            onClick={() => setShowPw((v) => !v)}
            aria-label="비밀번호 표시 전환"
          >
            <i className={showPw ? "ti ti-eye-off" : "ti ti-eye"} style={{ fontSize: 16 }} />
          </button>
        </div>

        <div style={s.validationRow}>
          <ValidationTag ok={hasLetter} label="영문" />
          <ValidationTag ok={hasNumber} label="숫자" />
          <ValidationTag ok={hasLength} label="8-20자 이내" />
        </div>

        <div style={{ ...s.inputWithIcon, marginTop: 10 }}>
          <input
            type={showConfirm ? "text" : "password"}
            placeholder="비밀번호를 다시 입력하세요."
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            style={s.input}
          />
          <button
            type="button"
            style={s.eyeButton}
            onClick={() => setShowConfirm((v) => !v)}
            aria-label="비밀번호 표시 전환"
          >
            <i className={showConfirm ? "ti ti-eye-off" : "ti ti-eye"} style={{ fontSize: 16 }} />
          </button>
        </div>
        {confirm.length > 0 && (
          <div style={s.validationRow}>
            <ValidationTag ok={isMatch} label="비밀번호 일치" />
          </div>
        )}
      </div>

      <div style={s.signupFooter}>
        <button
          type="button"
          disabled={!isValid}
          onClick={() => onNext(password)}
          style={{
            ...s.primaryButton,
            opacity: !isValid ? 0.4 : 1,
            cursor: !isValid ? "not-allowed" : "pointer",
          }}
        >
          다음
        </button>
      </div>
      <HomeIndicator />
    </PhoneFrame>
  );
}

function ValidationTag({ ok, label }) {
  return (
    <span style={{ ...s.validationTag, color: ok ? "#1D9E75" : "#B0B0B0" }}>
      {label} {ok && <i className="ti ti-check" style={{ fontSize: 12 }} />}
    </span>
  );
}

// ----------------------------------------------------
// 화면 7-8: 회원가입 1-2 (4/5) - 휴대폰 본인인증
// ----------------------------------------------------
const CARRIERS = ["SKT", "KT", "LG U+", "알뜰폰"];
const CODE_TIMER_SECONDS = 180;

function SignUpPhoneScreen({ onBack, onNext }) {
  const [name, setName] = useState("");
  const [residentFront, setResidentFront] = useState("");
  const [carrier, setCarrier] = useState("");
  const [phone, setPhone] = useState("");
  const [codeRequested, setCodeRequested] = useState(false);
  const [code, setCode] = useState("");
  const [secondsLeft, setSecondsLeft] = useState(CODE_TIMER_SECONDS);
  const [requesting, setRequesting] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [codeError, setCodeError] = useState("");
  const timerRef = useRef(null);

  useEffect(() => {
    if (!codeRequested) return;
    timerRef.current = setInterval(() => {
      setSecondsLeft((s) => (s > 0 ? s - 1 : 0));
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [codeRequested]);

  const formatTime = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const infoComplete = name && residentFront.length === 7 && carrier && phone;

  const handleRequestCode = async () => {
    if (!infoComplete) return;
    setRequesting(true);
    try {
      await requestPhoneVerification({ name, residentFront, carrier, phone });
      setCodeRequested(true);
      setSecondsLeft(CODE_TIMER_SECONDS);
    } finally {
      setRequesting(false);
    }
  };

  const handleResend = async () => {
    setRequesting(true);
    try {
      await requestPhoneVerification({ name, residentFront, carrier, phone });
      setSecondsLeft(CODE_TIMER_SECONDS);
      setCode("");
      setCodeError("");
    } finally {
      setRequesting(false);
    }
  };

  const handleConfirmCode = async () => {
    if (code.length !== 6) {
      setCodeError("인증번호 6자리를 입력해주세요.");
      return;
    }
    setConfirming(true);
    try {
      const ok = await confirmVerificationCode(code);
      if (!ok) {
        setCodeError("인증번호가 올바르지 않습니다.");
        return;
      }
      onNext({ name, phone });
    } finally {
      setConfirming(false);
    }
  };

  return (
    <PhoneFrame>
      <StatusBar />
      <StepHeader onBack={onBack} step={4} totalSteps={5} />

      <div style={s.signupBody}>
        <p style={s.stepTitle}>
          휴대폰 본인인증을
          <br />
          진행합니다.
        </p>

        <input
          type="text"
          placeholder="이름"
          value={name}
          onChange={(e) => setName(e.target.value)}
          style={s.input}
          disabled={codeRequested}
        />
        <input
          type="text"
          placeholder="주민등록번호 앞 7자리"
          value={residentFront}
          onChange={(e) => setResidentFront(e.target.value.replace(/\D/g, "").slice(0, 7))}
          style={{ ...s.input, marginTop: 10 }}
          disabled={codeRequested}
        />
        <div style={{ ...s.inlineRow, marginTop: 10 }}>
          <select
            value={carrier}
            onChange={(e) => setCarrier(e.target.value)}
            style={s.select}
            disabled={codeRequested}
          >
            <option value="">통신사</option>
            {CARRIERS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <input
            type="tel"
            placeholder="휴대폰 번호 입력"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
            style={{ ...s.input, flex: 1 }}
            disabled={codeRequested}
          />
        </div>

        {codeRequested && (
          <div style={{ ...s.inlineRow, marginTop: 14 }}>
            <input
              type="text"
              placeholder="인증번호 6자리 입력"
              value={code}
              onChange={(e) => {
                setCode(e.target.value.replace(/\D/g, "").slice(0, 6));
                setCodeError("");
              }}
              style={{ ...s.input, flex: 1 }}
            />
            <span style={s.timerText}>{formatTime(secondsLeft)}</span>
            <button
              type="button"
              onClick={handleResend}
              disabled={requesting}
              style={s.resendButton}
            >
              재전송
            </button>
          </div>
        )}
        {codeError && <p style={s.fieldError}>{codeError}</p>}
      </div>

      <div style={s.signupFooter}>
        {!codeRequested ? (
          <button
            type="button"
            disabled={!infoComplete || requesting}
            onClick={handleRequestCode}
            style={{
              ...s.primaryButton,
              opacity: !infoComplete || requesting ? 0.4 : 1,
              cursor: !infoComplete || requesting ? "not-allowed" : "pointer",
            }}
          >
            {requesting ? "발송중..." : "다음"}
          </button>
        ) : (
          <button
            type="button"
            disabled={confirming}
            onClick={handleConfirmCode}
            style={{ ...s.primaryButton, opacity: confirming ? 0.6 : 1 }}
          >
            {confirming ? "확인중..." : "다음"}
          </button>
        )}
      </div>
      <HomeIndicator />
    </PhoneFrame>
  );
}

// ----------------------------------------------------
// 화면 9: 가입 완료
// ----------------------------------------------------
function SignUpDoneScreen({ nickname, onGoHome }) {
  return (
    <PhoneFrame>
      <StatusBar />
      <div style={s.signupHeaderRow}>
        <div style={{ width: 20 }} />
      </div>
      <div style={s.progressWrap}>
        <div style={s.progressBarBg}>
          <div style={{ ...s.progressBarFill, width: "100%" }} />
        </div>
      </div>

      <div style={s.doneBody}>
        <p style={s.doneWelcome}>
          반가워요 <b>{nickname || "회원"}</b> 님!
        </p>
        <div style={s.doneCircle}>
          <i className="ti ti-check" style={{ fontSize: 40, color: "#FFFFFF" }} />
        </div>
        <p style={s.doneLabel}>가입 완료</p>
      </div>

      <div style={s.signupFooter}>
        <button type="button" onClick={onGoHome} style={s.secondaryButton}>
          홈으로 이동하기
        </button>
      </div>
      <HomeIndicator />
    </PhoneFrame>
  );
}

// ----------------------------------------------------
// 최상위 App: 화면 전환 관리
// ----------------------------------------------------
export default function App() {
  const [screen, setScreen] = useState("splash");
  const [signupData, setSignupData] = useState({ id: "", password: "", name: "", phone: "" });

  if (screen === "splash") return <SplashScreen onFinish={() => setScreen("login")} />;

  if (screen === "login")
    return (
      <LoginScreen
        onGoSignUp={() => setScreen("signupTerms")}
        onLoginSuccess={() => setScreen("done")}
      />
    );

  if (screen === "signupTerms")
    return (
      <SignUpTermsScreen
        onBack={() => setScreen("login")}
        onNext={() => setScreen("signupId")}
      />
    );

  if (screen === "signupId")
    return (
      <SignUpIdScreen
        onBack={() => setScreen("signupTerms")}
        onNext={(id) => {
          setSignupData((p) => ({ ...p, id }));
          setScreen("signupPassword");
        }}
      />
    );

  if (screen === "signupPassword")
    return (
      <SignUpPasswordScreen
        onBack={() => setScreen("signupId")}
        onNext={(password) => {
          setSignupData((p) => ({ ...p, password }));
          setScreen("signupPhone");
        }}
      />
    );

  if (screen === "signupPhone")
    return (
      <SignUpPhoneScreen
        onBack={() => setScreen("signupPassword")}
        onNext={async ({ name, phone }) => {
          const merged = { ...signupData, name, phone };
          setSignupData(merged);
          await completeSignUp(merged);
          setScreen("signupDone");
        }}
      />
    );

  if (screen === "signupDone")
    return (
      <SignUpDoneScreen
        nickname={signupData.id}
        onGoHome={() => setScreen("login")}
      />
    );

  // 로그인 성공
  return (
    <PhoneFrame>
      <StatusBar />
      <div style={s.doneBody}>
        <i className="ti ti-circle-check" style={{ fontSize: 40, color: "#1D9E75" }} />
        <p style={{ fontSize: 13.5, color: "#3A3A3A" }}>로그인되었습니다.</p>
      </div>
      <HomeIndicator />
    </PhoneFrame>
  );
}

// ----------------------------------------------------
// 스타일 — 와이어프레임 톤(그레이스케일, 얇은 보더, 최소 장식) 유지
// ----------------------------------------------------
const s = {
  phone: {
    width: 375,
    minHeight: 720,
    margin: "0 auto",
    background: "#FFFFFF",
    border: "1px solid #E5E5E5",
    borderRadius: 12,
    display: "flex",
    flexDirection: "column",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    color: "#1A1A1A",
    position: "relative",
  },
  statusBar: {
    display: "flex",
    justifyContent: "space-between",
    padding: "10px 18px 0",
    fontSize: 13,
    fontWeight: 600,
  },
  statusIcons: { display: "flex", gap: 4, alignItems: "center" },

  logoPlaceholder: {
    width: 64,
    height: 64,
    border: "1px solid #D9D9D9",
    borderRadius: 4,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },

  splashBody: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
  },
  splashTitle: { fontWeight: 700, fontSize: 15, margin: 0 },

  loginBody: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "56px 24px 0",
  },
  loginTitle: { fontWeight: 700, fontSize: 18, margin: "4px 0 4px" },
  loginSubtitle: { fontSize: 12.5, color: "#8A8A8A", margin: "0 0 28px" },

  input: {
    width: "100%",
    height: 42,
    padding: "0 12px",
    fontSize: 13,
    border: "1px solid #DADADA",
    borderRadius: 6,
    outline: "none",
    boxSizing: "border-box",
    color: "#1A1A1A",
    background: "#FFFFFF",
  },
  inputWithIcon: { position: "relative" },
  eyeButton: {
    position: "absolute",
    right: 10,
    top: "50%",
    transform: "translateY(-50%)",
    background: "none",
    border: "none",
    color: "#B0B0B0",
    cursor: "pointer",
    padding: 4,
  },
  guestLinkCentered: {
    alignSelf: "center",
    marginTop: 10,
    fontSize: 11.5,
    color: "#8A8A8A",
    background: "none",
    border: "none",
    textDecoration: "underline",
    cursor: "pointer",
    padding: 0,
  },
  loginError: { width: "100%", fontSize: 12, color: "#C0392B", margin: "10px 0 0", textAlign: "left" },
  loginButton: {
    width: "100%",
    height: 42,
    marginTop: 16,
    borderRadius: 6,
    border: "1px solid #DADADA",
    background: "#F2F2F2",
    color: "#3A3A3A",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
  },
  linkRow: { display: "flex", alignItems: "center", gap: 8, marginTop: 24 },
  linkText: { fontSize: 11.5, color: "#8A8A8A", background: "none", border: "none", cursor: "pointer", padding: 0 },
  linkDivider: { fontSize: 11.5, color: "#DADADA" },

  bottomTextWrap: { textAlign: "center", paddingBottom: 10 },
  bottomText: { fontSize: 11.5, color: "#B0B0B0", margin: "0 0 8px" },
  dots: { display: "flex", justifyContent: "center", gap: 5 },
  dot: { width: 5, height: 5, borderRadius: "50%", background: "#B0B0B0" },

  homeIndicatorWrap: { display: "flex", justifyContent: "center", padding: "8px 0 14px" },
  homeIndicator: { width: 110, height: 4, borderRadius: 2, background: "#1A1A1A" },

  signupHeaderRow: { display: "flex", alignItems: "center", padding: "14px 18px 0" },
  backButton: { background: "none", border: "none", cursor: "pointer", padding: 4, color: "#1A1A1A" },
  progressWrap: { padding: "8px 18px 0" },
  progressBarBg: { width: "100%", height: 3, borderRadius: 2, background: "#EDEDED", overflow: "hidden" },
  progressBarFill: { height: "100%", background: "#1A1A1A", transition: "width 0.2s ease" },

  signupBody: { flex: 1, padding: "20px 22px 0" },
  signupTitle: { fontSize: 15.5, lineHeight: 1.5, margin: "0 0 22px", fontWeight: 400 },
  stepTitle: { fontSize: 17, lineHeight: 1.4, margin: "0 0 22px", fontWeight: 600, color: "#1A1A1A" },

  termsList: { display: "flex", flexDirection: "column" },
  termRow: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "9px 0" },
  termLabelWrap: { display: "flex", alignItems: "center", gap: 8, cursor: "pointer" },
  checkbox: { width: 15, height: 15, accentColor: "#3A3A3A", flexShrink: 0 },
  termLabel: { fontSize: 12.5, color: "#3A3A3A" },
  requiredTag: { color: "#3A3A3A", fontWeight: 600 },
  optionalTag: { color: "#8A8A8A", fontWeight: 600 },
  viewLink: { fontSize: 11, color: "#B0B0B0", textDecoration: "underline", background: "none", border: "none", cursor: "pointer", padding: 0 },
  termsDivider: { height: 1, background: "#EDEDED", margin: "14px 0" },
  allAgreeRow: { display: "flex", alignItems: "center", gap: 8, cursor: "pointer" },
  allAgreeLabel: { fontSize: 12.5, fontWeight: 600, color: "#1A1A1A" },

  fieldError: { margin: "8px 2px 0", fontSize: 12, color: "#C0392B" },
  validationRow: { display: "flex", gap: 10, marginTop: 8, marginLeft: 2 },
  validationTag: { fontSize: 11, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 2 },

  inlineRow: { display: "flex", gap: 8 },
  select: {
    width: 92,
    height: 42,
    padding: "0 8px",
    fontSize: 13,
    border: "1px solid #DADADA",
    borderRadius: 6,
    background: "#FFFFFF",
    color: "#1A1A1A",
    flexShrink: 0,
  },
  timerText: { fontSize: 12, color: "#C0392B", alignSelf: "center", flexShrink: 0 },
  resendButton: {
    height: 42,
    padding: "0 12px",
    fontSize: 12,
    fontWeight: 600,
    borderRadius: 6,
    border: "1px solid #DADADA",
    background: "#F2F2F2",
    color: "#3A3A3A",
    cursor: "pointer",
    flexShrink: 0,
  },

  signupFooter: { padding: "16px 22px 6px" },
  primaryButton: {
    width: "100%",
    height: 48,
    borderRadius: 24,
    border: "none",
    background: "#1A1A1A",
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: 600,
  },
  secondaryButton: {
    width: "100%",
    height: 46,
    borderRadius: 24,
    border: "1px solid #DADADA",
    background: "#F2F2F2",
    color: "#3A3A3A",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
  },

  doneBody: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: 18,
    padding: "0 24px",
  },
  doneWelcome: { fontSize: 15, color: "#1A1A1A", margin: 0 },
  doneCircle: {
    width: 84,
    height: 84,
    borderRadius: "50%",
    background: "#1A1A1A",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  doneLabel: { fontSize: 14, color: "#3A3A3A", margin: 0 },

  collectBody: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "0 28px",
    gap: 24,
  },
  collectText: { fontSize: 15, lineHeight: 1.5, textAlign: "center", color: "#1A1A1A", margin: 0 },
  searchTrigger: {
    width: "100%",
    height: 42,
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "0 14px",
    border: "1px solid #DADADA",
    borderRadius: 21,
    background: "#FFFFFF",
    cursor: "pointer",
  },
  searchTriggerText: { fontSize: 12.5, color: "#B0B0B0" },

  searchHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "10px 16px 0",
  },
  searchHeaderTitle: { fontSize: 15, fontWeight: 700 },
  iconButton: { background: "none", border: "none", color: "#1A1A1A", cursor: "pointer", padding: 4 },

  searchBarRow: { display: "flex", gap: 8, padding: "12px 16px 0" },
  searchBarWrap: {
    flex: 1,
    display: "flex",
    alignItems: "center",
    gap: 8,
    height: 38,
    padding: "0 12px",
    border: "1px solid #DADADA",
    borderRadius: 19,
    background: "#FAFAFA",
  },
  searchBarInput: { flex: 1, border: "none", outline: "none", background: "none", fontSize: 12.5, color: "#1A1A1A" },
  locationButton: {
    width: 38,
    height: 38,
    borderRadius: "50%",
    border: "1px solid #DADADA",
    background: "#FFFFFF",
    color: "#3A3A3A",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },

  resultsList: { flex: 1, padding: "8px 16px 0", overflowY: "auto" },
  resultRow: {
    width: "100%",
    display: "flex",
    alignItems: "flex-start",
    gap: 8,
    padding: "12px 0",
    borderBottom: "1px solid #F0F0F0",
    background: "none",
    border: "none",
    borderBottomWidth: 1,
    borderBottomStyle: "solid",
    borderBottomColor: "#F0F0F0",
    cursor: "pointer",
    textAlign: "left",
  },
  resultInfo: { flex: 1 },
  resultName: { fontSize: 13, fontWeight: 600, color: "#1A1A1A", margin: "0 0 2px" },
  resultAddress: { fontSize: 11, color: "#8A8A8A", margin: "0 0 2px" },
  resultReview: { fontSize: 11, color: "#B0B0B0", margin: 0 },
  resultMeta: { display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4, flexShrink: 0 },
  resultCategory: { fontSize: 11, color: "#3A3A3A", fontWeight: 600 },
  resultDistance: { fontSize: 11, color: "#B0B0B0" },
  noResults: { textAlign: "center", color: "#B0B0B0", fontSize: 12.5, marginTop: 40 },

  sheetOverlay: {
    position: "absolute",
    inset: 0,
    background: "rgba(0,0,0,0.35)",
    display: "flex",
    alignItems: "flex-end",
    borderRadius: 12,
  },
  sheet: {
    width: "100%",
    background: "#FFFFFF",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: "10px 20px 20px",
    boxSizing: "border-box",
  },
  sheetHandle: { width: 36, height: 4, borderRadius: 2, background: "#DADADA", margin: "0 auto 12px" },
  sheetImage: {
    width: "100%",
    height: 96,
    border: "1px solid #E5E5E5",
    borderRadius: 8,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  sheetTitleRow: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  sheetName: { fontSize: 15, fontWeight: 700, margin: 0, color: "#1A1A1A" },
  sheetRating: { fontSize: 11.5, color: "#1A1A1A", display: "flex", alignItems: "center", gap: 3 },
  sheetSub: { fontSize: 11.5, color: "#8A8A8A", margin: "4px 0 10px" },
  sheetTagsRow: { display: "flex", gap: 8, marginBottom: 14 },
  tagOpen: { fontSize: 10.5, fontWeight: 600, color: "#1D9E75", background: "#E1F5EE", padding: "3px 8px", borderRadius: 5 },
  tagSaved: { fontSize: 10.5, fontWeight: 600, color: "#3A3A3A", background: "#F2F2F2", padding: "3px 8px", borderRadius: 5, display: "inline-flex", alignItems: "center", gap: 3 },
  sheetSectionLabel: { fontSize: 10.5, fontWeight: 700, letterSpacing: 0.5, color: "#8A8A8A", margin: "0 0 8px" },
  sheetThumbRow: { display: "flex", gap: 8, marginBottom: 18 },
  sheetThumb: {
    width: 56,
    height: 56,
    border: "1px solid #E5E5E5",
    borderRadius: 6,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  saveButton: {
    width: "100%",
    height: 46,
    borderRadius: 24,
    border: "none",
    background: "#1A1A1A",
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
  },
};
